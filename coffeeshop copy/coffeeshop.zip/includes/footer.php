<footer class="bg-blue-600 text-white text-center py-6 mt-24 shadow-lg">
        <p>&copy; 2025 Coffee Shop. All rights reserved.</p>
    </footer>

</body>
</html>
